# Little Ledger — Everyday Expense Manager

A simple expense tracker designed for both college students and families. It uses a warm cream, soft green, and yellow visual style.

## Features

- Student mode and Family mode, each with relevant expense categories
- Monthly spending limit and remaining-budget indicator
- Weekly spending summary
- Category-wise spending breakdown
- Add, edit, and delete expenses
- Search expenses and filter by category
- Export expense history to CSV
- Light and dark themes
- SQLite database storage
- Basic validation for expense amounts, dates, categories, and budget values

## Tech stack

- Python
- Flask
- SQLite
- HTML and Jinja2
- CSS
- Small amount of JavaScript for the edit dialog and interface interactions

## Run locally

1. Install Python 3.10 or newer.
2. Open a terminal in this project folder.
3. Create and activate a virtual environment (recommended):

   ```bash
   python -m venv .venv
   ```

   Windows:

   ```bash
   .venv\Scripts\activate
   ```

   macOS/Linux:

   ```bash
   source .venv/bin/activate
   ```

4. Install dependencies:

   ```bash
   pip install -r requirements.txt
   ```

5. Start the app:

   ```bash
   python app.py
   ```

6. Open http://127.0.0.1:5000 in your browser.

The app creates `expenses.db` automatically on first run. The database is intentionally excluded from Git by `.gitignore`; each person gets their own local database.

## Existing database

If you already have an `expenses.db` from the earlier version, place it in the same folder as `app.py` before running the redesigned version. The app keeps the existing `expenses` and `settings` tables and adds the new `mode` setting if needed. Back up your database before upgrading.

## Notes

- The app currently supports one local user and stores data in a local SQLite database.
- Expense dates are restricted to the current month, matching the original project's workflow.
- Tailwind CSS, Font Awesome, and Google Fonts are loaded from CDNs, so an internet connection helps the page styling and icons load.
- For public deployment, turn off Flask debug mode and add production security protections such as CSRF protection and user authentication.

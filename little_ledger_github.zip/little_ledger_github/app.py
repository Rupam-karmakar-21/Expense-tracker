from flask import Flask, render_template_string, request, redirect, url_for, Response
import sqlite3
import csv
import io
import calendar
from datetime import datetime, date, timedelta

app = Flask(__name__)
DB_NAME = "expenses.db"

STUDENT_CATEGORIES = [
    "Food & Snacks", "Travel", "Books & Stationery",
    "College Fees", "Mobile Recharge", "Entertainment", "Other"
]
FAMILY_CATEGORIES = [
    "Groceries", "Household", "Bills & Utilities",
    "Healthcare", "Transport", "Shopping", "Other"
]
ALL_CATEGORIES = sorted(set(STUDENT_CATEGORIES + FAMILY_CATEGORIES))


def get_db():
    conn = sqlite3.connect(DB_NAME)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    """Create tables and add new settings without deleting existing data."""
    conn = get_db()
    conn.execute("""
        CREATE TABLE IF NOT EXISTS expenses (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            amount REAL NOT NULL,
            category TEXT NOT NULL,
            date TEXT NOT NULL
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS settings (
            key TEXT PRIMARY KEY,
            value TEXT NOT NULL
        )
    """)
    conn.execute(
        "INSERT OR IGNORE INTO settings (key, value) VALUES ('theme', 'light')"
    )
    conn.execute(
        "INSERT OR IGNORE INTO settings (key, value) VALUES ('monthly_budget', '25000')"
    )
    conn.execute(
        "INSERT OR IGNORE INTO settings (key, value) VALUES ('mode', 'student')"
    )

    # Add sample entries only when the database is completely empty.
    count = conn.execute("SELECT COUNT(*) FROM expenses").fetchone()[0]
    if count == 0:
        current_ym = datetime.now().strftime("%Y-%m")
        samples = [
            ("Lunch", 120.0, "Food & Snacks", f"{current_ym}-02"),
            ("Bus pass", 450.0, "Travel", f"{current_ym}-04"),
            ("Notebook", 85.0, "Books & Stationery", f"{current_ym}-06"),
        ]
        conn.executemany(
            "INSERT INTO expenses (title, amount, category, date) VALUES (?, ?, ?, ?)",
            samples
        )
    conn.commit()
    conn.close()


def setting(conn, key, default):
    row = conn.execute("SELECT value FROM settings WHERE key = ?", (key,)).fetchone()
    return row["value"] if row else default


def save_setting(conn, key, value):
    conn.execute(
        "INSERT INTO settings (key, value) VALUES (?, ?) "
        "ON CONFLICT(key) DO UPDATE SET value = excluded.value",
        (key, str(value))
    )


TEMPLATE = r"""
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Little Ledger | Everyday Expense Manager</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700;800&family=Manrope:wght@500;600;700;800&display=swap" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
  <style>
    :root {
      --page: #fbf8ef;
      --surface: #fffefa;
      --surface-soft: #f5f1e5;
      --ink: #26352d;
      --muted: #7b877d;
      --line: #e9e5d8;
      --green: #477b5c;
      --green-dark: #315d43;
      --green-pale: #e8f1e7;
      --yellow: #f3d36b;
      --yellow-pale: #fff5cf;
      --red: #c66a55;
      --shadow: 0 12px 34px rgba(56, 69, 51, .07);
    }
    * { box-sizing: border-box; }
    body {
      margin: 0; background: var(--page); color: var(--ink);
      font-family: "DM Sans", sans-serif;
      background-image: radial-gradient(#e8e2cf 0.7px, transparent 0.7px);
      background-size: 18px 18px;
    }
    h1,h2,h3,.brand { font-family: "Manrope", sans-serif; }
    .shell { max-width: 1180px; margin: 0 auto; padding: 30px 22px 56px; }
    .surface { background: var(--surface); border: 1px solid var(--line); border-radius: 22px; box-shadow: var(--shadow); }
    .topbar { display:flex; align-items:center; justify-content:space-between; gap:18px; padding:18px 22px; margin-bottom:22px; }
    .brand-mark { width:44px; height:44px; display:grid; place-items:center; border-radius:15px; background:var(--green-pale); color:var(--green-dark); font-size:19px; }
    .eyebrow { color:var(--muted); text-transform:uppercase; letter-spacing:.13em; font-size:10px; font-weight:800; }
    .subtle { color:var(--muted); }
    .control, input, select { width:100%; border:1px solid var(--line); background:#fffefa; color:var(--ink); border-radius:12px; padding:11px 13px; outline:none; font:inherit; font-size:13px; }
    input:focus, select:focus { border-color:#86a98d; box-shadow:0 0 0 3px rgba(71,123,92,.12); }
    label { display:block; font-size:11px; font-weight:800; color:#68766b; margin-bottom:7px; }
    .btn { border:0; border-radius:12px; padding:11px 16px; font-size:13px; font-weight:800; cursor:pointer; transition:.18s ease; display:inline-flex; align-items:center; justify-content:center; gap:8px; text-decoration:none; }
    .btn:hover { transform:translateY(-1px); filter:brightness(.98); }
    .btn-green { background:var(--green); color:white; box-shadow:0 6px 15px rgba(71,123,92,.18); }
    .btn-yellow { background:var(--yellow); color:#51451e; }
    .btn-soft { background:var(--green-pale); color:var(--green-dark); }
    .btn-plain { background:transparent; color:var(--muted); border:1px solid var(--line); }
    .hero { display:flex; justify-content:space-between; align-items:flex-end; gap:20px; margin:26px 2px 20px; }
    .hero h1 { font-size:clamp(27px,4vw,38px); letter-spacing:-.045em; line-height:1.12; margin:8px 0; }
    .mode-switch { display:flex; gap:5px; padding:5px; background:#f1eddf; border:1px solid var(--line); border-radius:14px; }
    .mode-switch button { border:0; padding:10px 13px; border-radius:10px; background:transparent; color:#778174; font-size:12px; font-weight:800; cursor:pointer; }
    .mode-switch button.active { background:var(--surface); color:var(--green-dark); box-shadow:0 2px 8px rgba(45,60,43,.08); }
    .stats { display:grid; grid-template-columns:repeat(4,minmax(0,1fr)); gap:14px; margin-bottom:16px; }
    .stat { padding:19px; min-height:136px; position:relative; overflow:hidden; }
    .stat-icon { width:36px; height:36px; display:grid; place-items:center; border-radius:12px; margin-bottom:15px; }
    .stat-value { font:800 25px "Manrope",sans-serif; letter-spacing:-.04em; margin-top:5px; }
    .stat-note { color:var(--muted); font-size:11px; margin-top:4px; }
    .content-grid { display:grid; grid-template-columns:minmax(0,1.35fr) minmax(280px,.85fr); gap:16px; align-items:start; }
    .panel { padding:21px; margin-bottom:16px; }
    .panel-title { display:flex; justify-content:space-between; align-items:center; gap:12px; margin-bottom:17px; }
    .panel-title h2 { font-size:16px; font-weight:800; margin:0; }
    .form-grid { display:grid; grid-template-columns:1.2fr .8fr 1fr 1fr; gap:11px; }
    .form-grid .wide { grid-column:1/-1; }
    .progress-track { width:100%; height:10px; border-radius:99px; background:#eeeadd; overflow:hidden; }
    .progress-fill { height:100%; border-radius:99px; background:linear-gradient(90deg,#8eb68c,#477b5c); }
    .category-row { display:grid; grid-template-columns:110px 1fr 78px; align-items:center; gap:10px; margin:13px 0; font-size:12px; }
    .category-track { height:8px; background:#f0eddf; border-radius:99px; overflow:hidden; }
    .category-fill { height:100%; background:#91b18b; border-radius:99px; }
    .week-box { background:var(--yellow-pale); border:1px solid #f2e6b6; border-radius:16px; padding:16px; }
    .table-wrap { overflow-x:auto; }
    table { width:100%; border-collapse:collapse; min-width:570px; }
    th { color:#8b9488; font-size:10px; letter-spacing:.1em; text-transform:uppercase; text-align:left; padding:12px 10px; border-bottom:1px solid var(--line); }
    td { padding:13px 10px; border-bottom:1px solid #f0ede4; font-size:12px; }
    tbody tr:last-child td { border-bottom:0; }
    .pill { display:inline-block; padding:5px 9px; border-radius:99px; background:var(--green-pale); color:var(--green-dark); font-size:10px; font-weight:800; }
    .icon-btn { border:0; background:transparent; color:#8b9488; padding:6px; cursor:pointer; }
    .icon-btn:hover { color:var(--green-dark); }
    .alert { padding:12px 15px; border-radius:13px; margin-bottom:15px; font-size:12px; }
    .alert-error { background:#fff0eb; border:1px solid #f1d0c4; color:#9b4c3a; }
    .alert-success { background:#eaf4e9; border:1px solid #d4e7d1; color:#315d43; }
    .toolbar { display:flex; gap:8px; align-items:center; flex-wrap:wrap; }
    .toolbar input,.toolbar select { width:auto; min-width:130px; padding:9px 11px; font-size:11px; }
    .empty { text-align:center; padding:30px 12px; color:var(--muted); font-size:12px; }
    .footer-note { text-align:center; color:#98a094; font-size:11px; padding-top:10px; }
    .modal-backdrop { display:none; position:fixed; inset:0; background:rgba(28,42,33,.42); z-index:20; padding:20px; align-items:center; justify-content:center; }
    .modal-backdrop.show { display:flex; }
    .modal { width:min(440px,100%); padding:22px; background:var(--surface); border:1px solid var(--line); border-radius:20px; box-shadow:0 25px 70px rgba(0,0,0,.2); }
    body.dark { --page:#202b24; --surface:#2b382f; --surface-soft:#354238; --ink:#f4f1e6; --muted:#b3bcae; --line:#465447; --green:#82aa83; --green-dark:#d5ead3; --green-pale:#3b5140; --yellow:#d7bd67; --yellow-pale:#514a30; --shadow:0 12px 34px rgba(0,0,0,.15); background-image:radial-gradient(#465447 .7px,transparent .7px); }
    body.dark .control, body.dark input, body.dark select { background:#354238; color:var(--ink); border-color:var(--line); }
    body.dark .mode-switch { background:#354238; border-color:var(--line); }
    body.dark .mode-switch button.active { background:#465447; }
    body.dark .progress-track, body.dark .category-track { background:#465447; }
    body.dark td { border-color:#3b493e; }
    body.dark th { border-color:#465447; }
    body.dark .week-box { border-color:#71653c; }
    @media(max-width:850px) { .stats { grid-template-columns:repeat(2,1fr); } .content-grid { grid-template-columns:1fr; } }
    @media(max-width:600px) {
      .shell { padding:15px 12px 35px; }
      .topbar { align-items:flex-start; padding:14px; }
      .hero { align-items:flex-start; flex-direction:column; }
      .form-grid { grid-template-columns:1fr 1fr; }
      .form-grid .wide { grid-column:1/-1; }
      .stat { min-height:120px; padding:15px; }
      .stat-value { font-size:21px; }
      .panel { padding:16px; }
      .toolbar { width:100%; }
      .toolbar input,.toolbar select { flex:1; min-width:0; width:100%; }
    }
  </style>
</head>
<body class="{{ 'dark' if theme == 'dark' else '' }}">
<div class="shell">
  <header class="surface topbar">
    <div class="flex items-center gap-3">
      <div class="brand-mark"><i class="fa-solid fa-leaf"></i></div>
      <div>
        <div class="brand font-extrabold text-lg tracking-tight">little ledger</div>
        <div class="subtle text-xs">Small spends. Clear plans.</div>
      </div>
    </div>
    <div class="flex items-center gap-2">
      <form action="{{ url_for('set_theme') }}" method="POST">
        <select name="theme" aria-label="Choose theme" onchange="this.form.submit()" class="!w-auto !py-2 !text-xs">
          <option value="light" {{ 'selected' if theme == 'light' else '' }}>☀ Light</option>
          <option value="dark" {{ 'selected' if theme == 'dark' else '' }}>☾ Dark</option>
        </select>
      </form>
      <a class="btn btn-plain !py-2 !px-3" href="{{ url_for('export_csv') }}"><i class="fa-solid fa-download"></i><span class="hidden sm:inline"> Export</span></a>
    </div>
  </header>

  {% if message %}<div class="alert alert-success"><i class="fa-solid fa-circle-check mr-2"></i>{{ message }}</div>{% endif %}
  {% if error %}<div class="alert alert-error"><i class="fa-solid fa-circle-exclamation mr-2"></i>{{ error }}</div>{% endif %}

  <section class="hero">
    <div>
      <div class="eyebrow">Your everyday money companion</div>
      <h1>{{ 'A little more control, every day.' if mode == 'student' else 'Keep the household on track.' }}</h1>
      <p class="subtle text-sm">{{ 'Keep an eye on campus life, food, travel and the little things.' if mode == 'student' else 'One simple place to keep track of groceries, bills and home spending.' }}</p>
    </div>
    <form action="{{ url_for('set_mode') }}" method="POST">
      <div class="mode-switch">
        <button name="mode" value="student" class="{{ 'active' if mode == 'student' else '' }}" type="submit"><i class="fa-solid fa-graduation-cap mr-1"></i> Student</button>
        <button name="mode" value="family" class="{{ 'active' if mode == 'family' else '' }}" type="submit"><i class="fa-solid fa-house-user mr-1"></i> Family</button>
      </div>
    </form>
  </section>

  <section class="stats">
    <div class="surface stat">
      <div class="stat-icon" style="background:#fff4cc;color:#9a7b23"><i class="fa-solid fa-wallet"></i></div>
      <div class="eyebrow">Monthly spending limit</div>
      <div class="stat-value">₹{{ "{:,.0f}".format(budget) }}</div>
      <button class="text-xs font-bold mt-2" style="color:var(--green)" onclick="openBudget()">Change limit <i class="fa-solid fa-arrow-right ml-1"></i></button>
    </div>
    <div class="surface stat">
      <div class="stat-icon" style="background:#fce9df;color:#b66b4e"><i class="fa-solid fa-bag-shopping"></i></div>
      <div class="eyebrow">Spent this month</div>
      <div class="stat-value">₹{{ "{:,.0f}".format(month_spent) }}</div>
      <div class="stat-note">{{ month_count }} recorded {{ 'expense' if month_count == 1 else 'expenses' }}</div>
    </div>
    <div class="surface stat">
      <div class="stat-icon" style="background:#e8f1e7;color:#477b5c"><i class="fa-solid fa-piggy-bank"></i></div>
      <div class="eyebrow">{{ 'Still available' if remaining >= 0 else 'Over your limit' }}</div>
      <div class="stat-value" style="color:{{ '#c66a55' if remaining < 0 else 'var(--green)' }}">₹{{ "{:,.0f}".format(remaining|abs) }}</div>
      <div class="stat-note">{{ 'Try to slow down a little' if remaining < 0 else 'You are doing great. Keep it up!' }}</div>
    </div>
    <div class="surface stat">
      <div class="stat-icon" style="background:#f7edda;color:#a17b37"><i class="fa-solid fa-star"></i></div>
      <div class="eyebrow">Biggest category</div>
      <div class="stat-value !text-xl">{{ top_category }}</div>
      <div class="stat-note">Your highest spend this month</div>
    </div>
  </section>

  <div class="content-grid">
    <main>
      <section class="surface panel">
        <div class="panel-title">
          <div><div class="eyebrow mb-1">Make a note of it</div><h2>Add a daily expense</h2></div>
          <span class="pill">{{ 'Student mode' if mode == 'student' else 'Family mode' }}</span>
        </div>
        <form action="{{ url_for('add_expense') }}" method="POST" class="form-grid">
          <div><label for="title">WHAT WAS IT FOR?</label><input id="title" name="title" maxlength="80" placeholder="{{ 'e.g. Lunch with friends' if mode == 'student' else 'e.g. Weekly groceries' }}" required></div>
          <div><label for="amount">AMOUNT (₹)</label><input id="amount" name="amount" type="number" min="0.01" step="0.01" placeholder="0.00" required></div>
          <div><label for="category">CATEGORY</label><select id="category" name="category" required>{% for cat in categories %}<option value="{{ cat }}">{{ cat }}</option>{% endfor %}</select></div>
          <div><label for="date">DATE</label><input id="date" name="date" type="date" value="{{ today }}" min="{{ month_start }}" max="{{ month_end }}" required></div>
          <div class="wide"><button class="btn btn-green w-full" type="submit"><i class="fa-solid fa-plus"></i> Save expense</button></div>
        </form>
        <p class="subtle text-xs mt-3"><i class="fa-regular fa-lightbulb mr-1"></i> You can record expenses for this month. Your entries stay saved on this device.</p>
      </section>

      <section class="surface panel">
        <div class="panel-title">
          <div><div class="eyebrow mb-1">The little details</div><h2>Recent expenses</h2></div>
          <span class="subtle text-xs">{{ filtered_count }} shown</span>
        </div>
        <form class="toolbar mb-4" method="GET" action="{{ url_for('index') }}">
          <input type="search" name="q" value="{{ search }}" placeholder="Search expenses...">
          <select name="category">
            <option value="">All categories</option>
            {% for cat in all_categories %}<option value="{{ cat }}" {{ 'selected' if selected_category == cat else '' }}>{{ cat }}</option>{% endfor %}
          </select>
          <button class="btn btn-soft !py-2 !px-3" type="submit"><i class="fa-solid fa-filter"></i> Filter</button>
          {% if search or selected_category %}<a class="btn btn-plain !py-2 !px-3" href="{{ url_for('index') }}">Clear</a>{% endif %}
        </form>
        <div class="table-wrap">
          <table>
            <thead><tr><th>Date</th><th>What was it?</th><th>Category</th><th class="text-right">Amount</th><th class="text-center">Edit</th></tr></thead>
            <tbody>
              {% for item in expenses %}
              <tr>
                <td class="whitespace-nowrap">{{ item['date'] }}</td>
                <td class="font-bold">{{ item['title'] }}</td>
                <td><span class="pill">{{ item['category'] }}</span></td>
                <td class="text-right font-extrabold whitespace-nowrap">₹{{ "{:,.2f}".format(item['amount']) }}</td>
                <td class="text-center whitespace-nowrap">
                  <button class="icon-btn" title="Edit expense" onclick="openEdit({{ item['id'] }}, {{ item['title']|tojson }}, {{ item['amount'] }}, {{ item['category']|tojson }}, {{ item['date']|tojson }})"><i class="fa-solid fa-pen"></i></button>
                  <form action="{{ url_for('delete_expense', expense_id=item['id']) }}" method="POST" class="inline" onsubmit="return confirm('Delete this expense?')"><button class="icon-btn" title="Delete expense" type="submit"><i class="fa-regular fa-trash-can"></i></button></form>
                </td>
              </tr>
              {% else %}
              <tr><td colspan="5"><div class="empty"><i class="fa-regular fa-folder-open text-2xl mb-2"></i><br>No expenses found. Add your first one above!</div></td></tr>
              {% endfor %}
            </tbody>
          </table>
        </div>
      </section>
    </main>

    <aside>
      <section class="surface panel">
        <div class="panel-title"><div><div class="eyebrow mb-1">A gentle nudge</div><h2>Monthly budget</h2></div><i class="fa-solid fa-seedling" style="color:var(--green)"></i></div>
        <div class="flex justify-between items-end mb-2"><span class="subtle text-xs">Budget used</span><strong class="text-lg">{{ budget_percent }}%</strong></div>
        <div class="progress-track"><div class="progress-fill" style="width:{{ budget_percent }}%;background:{{ '#c66a55' if month_spent > budget else '' }}"></div></div>
        <div class="flex justify-between mt-3 text-xs"><span class="subtle">₹{{ "{:,.0f}".format(month_spent) }} spent</span><span class="font-bold">₹{{ "{:,.0f}".format(budget) }} limit</span></div>
        {% if remaining < 0 %}<p class="text-xs mt-4" style="color:var(--red)">You are ₹{{ "{:,.0f}".format(remaining|abs) }} over your limit. Review your recent expenses.</p>
        {% elif budget_percent >= 80 %}<p class="text-xs mt-4" style="color:#a17b37">You have used most of your budget. Keep an eye on the rest of the month.</p>
        {% else %}<p class="text-xs mt-4 subtle">You still have room in your budget. Nice work keeping track!</p>{% endif %}
      </section>

      <section class="surface panel">
        <div class="panel-title"><div><div class="eyebrow mb-1">Your week at a glance</div><h2>This week's spending</h2></div><i class="fa-regular fa-calendar" style="color:var(--green)"></i></div>
        <div class="week-box">
          <div class="eyebrow" style="color:#89743b">Monday – today</div>
          <div class="text-2xl font-extrabold mt-1" style="font-family:Manrope">₹{{ "{:,.2f}".format(week_spent) }}</div>
          <div class="text-xs mt-1" style="color:#89743b">{{ week_count }} {{ 'expense' if week_count == 1 else 'expenses' }} this week</div>
        </div>
      </section>

      <section class="surface panel">
        <div class="panel-title"><div><div class="eyebrow mb-1">Spending patterns</div><h2>Where it goes</h2></div></div>
        {% if category_rows %}
          {% for cat, amount, percent in category_rows %}
          <div class="category-row">
            <span class="font-bold truncate">{{ cat }}</span>
            <div class="category-track"><div class="category-fill" style="width:{{ percent }}%"></div></div>
            <span class="text-right font-bold">₹{{ "{:,.0f}".format(amount) }}</span>
          </div>
          {% endfor %}
        {% else %}
          <div class="empty">Your category breakdown will appear after you add expenses.</div>
        {% endif %}
      </section>
    </aside>
  </div>
  <div class="footer-note">Made for everyday life · Keep it simple, keep it mindful 🌱</div>
</div>

<div class="modal-backdrop" id="budgetModal" onclick="if(event.target===this)closeBudget()">
  <div class="modal">
    <div class="flex justify-between items-center mb-4"><h2 class="font-extrabold text-lg">Set your monthly limit</h2><button class="icon-btn" onclick="closeBudget()"><i class="fa-solid fa-xmark"></i></button></div>
    <form action="{{ url_for('set_budget') }}" method="POST">
      <label for="new_budget">MONTHLY BUDGET (₹)</label>
      <input id="new_budget" type="number" name="monthly_budget" min="1" step="0.01" value="{{ budget }}" required>
      <div class="flex gap-2 mt-4"><button class="btn btn-green flex-1" type="submit">Save limit</button><button class="btn btn-plain" type="button" onclick="closeBudget()">Cancel</button></div>
    </form>
  </div>
</div>

<div class="modal-backdrop" id="editModal" onclick="if(event.target===this)closeEdit()">
  <div class="modal">
    <div class="flex justify-between items-center mb-4"><h2 class="font-extrabold text-lg">Edit expense</h2><button class="icon-btn" onclick="closeEdit()"><i class="fa-solid fa-xmark"></i></button></div>
    <form id="editForm" method="POST">
      <div class="mb-3"><label for="edit_title">DESCRIPTION</label><input id="edit_title" name="title" maxlength="80" required></div>
      <div class="mb-3"><label for="edit_amount">AMOUNT (₹)</label><input id="edit_amount" name="amount" type="number" min="0.01" step="0.01" required></div>
      <div class="mb-3"><label for="edit_category">CATEGORY</label><select id="edit_category" name="category">{% for cat in all_categories %}<option value="{{ cat }}">{{ cat }}</option>{% endfor %}</select></div>
      <div class="mb-3"><label for="edit_date">DATE</label><input id="edit_date" name="date" type="date" min="{{ month_start }}" max="{{ month_end }}" required></div>
      <div class="flex gap-2 mt-4"><button class="btn btn-green flex-1" type="submit">Save changes</button><button class="btn btn-plain" type="button" onclick="closeEdit()">Cancel</button></div>
    </form>
  </div>
</div>

<script>
  function openBudget() { document.getElementById('budgetModal').classList.add('show'); }
  function closeBudget() { document.getElementById('budgetModal').classList.remove('show'); }
  function openEdit(id, title, amount, category, date) {
    const form = document.getElementById('editForm');
    form.action = '/edit/' + id;
    document.getElementById('edit_title').value = title;
    document.getElementById('edit_amount').value = amount;
    document.getElementById('edit_category').value = category;
    document.getElementById('edit_date').value = date;
    document.getElementById('editModal').classList.add('show');
  }
  function closeEdit() { document.getElementById('editModal').classList.remove('show'); }
</script>
</body>
</html>
"""


@app.route("/")
def index():
    conn = get_db()
    mode = setting(conn, "mode", "student")
    theme = setting(conn, "theme", "light")
    if mode not in ("student", "family"):
        mode = "student"
    if theme not in ("light", "dark"):
        theme = "light"

    try:
        budget = float(setting(conn, "monthly_budget", "25000"))
    except ValueError:
        budget = 25000.0

    now = date.today()
    current_ym = now.strftime("%Y-%m")
    month_start = now.replace(day=1).isoformat()
    month_end = date(now.year, now.month, calendar.monthrange(now.year, now.month)[1]).isoformat()
    today = now.isoformat()
    week_start = (now - timedelta(days=now.weekday())).isoformat()

    all_rows = conn.execute(
        "SELECT * FROM expenses ORDER BY date DESC, id DESC"
    ).fetchall()
    month_rows = [r for r in all_rows if r["date"].startswith(current_ym)]
    month_spent = sum(float(r["amount"]) for r in month_rows)
    remaining = budget - month_spent
    month_count = len(month_rows)
    week_rows = [r for r in month_rows if week_start <= r["date"] <= today]
    week_spent = sum(float(r["amount"]) for r in week_rows)
    week_count = len(week_rows)

    totals = {}
    for row in month_rows:
        totals[row["category"]] = totals.get(row["category"], 0) + float(row["amount"])
    top_category = max(totals, key=totals.get) if totals else "Not yet"
    category_rows = [
        (cat, amount, min(100, round((amount / max(month_spent, 1)) * 100)))
        for cat, amount in sorted(totals.items(), key=lambda x: x[1], reverse=True)
    ][:6]
    budget_percent = min(100, round((month_spent / budget) * 100)) if budget > 0 else 100

    search = request.args.get("q", "").strip()[:80]
    selected_category = request.args.get("category", "").strip()
    filtered = list(all_rows)
    if search:
        needle = search.lower()
        filtered = [r for r in filtered if needle in r["title"].lower() or needle in r["category"].lower()]
    if selected_category in ALL_CATEGORIES:
        filtered = [r for r in filtered if r["category"] == selected_category]
    filtered_count = len(filtered)
    categories = STUDENT_CATEGORIES if mode == "student" else FAMILY_CATEGORIES
    conn.close()

    return render_template_string(
        TEMPLATE,
        mode=mode, theme=theme, budget=budget, month_spent=month_spent,
        remaining=remaining, month_count=month_count, top_category=top_category,
        budget_percent=budget_percent, week_spent=week_spent, week_count=week_count,
        category_rows=category_rows, expenses=filtered, filtered_count=filtered_count,
        categories=categories, all_categories=ALL_CATEGORIES,
        today=today, month_start=month_start, month_end=month_end,
        search=search, selected_category=selected_category,
        message=request.args.get("message"), error=request.args.get("error")
    )


@app.route("/add", methods=["POST"])
def add_expense():
    title = request.form.get("title", "").strip()
    category = request.form.get("category", "").strip()
    date_value = request.form.get("date", "").strip()
    try:
        amount = float(request.form.get("amount", "0"))
        parsed_date = date.fromisoformat(date_value)
    except (ValueError, TypeError):
        return redirect(url_for("index", error="Please enter a valid amount and date."))

    now = date.today()
    if not title or len(title) > 80:
        return redirect(url_for("index", error="Please enter a description (up to 80 characters)."))
    if amount <= 0:
        return redirect(url_for("index", error="Expense amount must be greater than zero."))
    if category not in ALL_CATEGORIES:
        return redirect(url_for("index", error="Please choose a valid category."))
    if parsed_date.year != now.year or parsed_date.month != now.month:
        return redirect(url_for("index", error="You can only add expenses for the current month."))

    conn = get_db()
    try:
        budget = float(setting(conn, "monthly_budget", "25000"))
    except ValueError:
        budget = 25000.0
    month_key = now.strftime("%Y-%m")
    spent = conn.execute(
        "SELECT COALESCE(SUM(amount), 0) FROM expenses WHERE date LIKE ?",
        (month_key + "%",)
    ).fetchone()[0]
    if amount > max(0, budget - float(spent)):
        conn.close()
        return redirect(url_for("index", error="This expense is higher than your remaining monthly budget. You can update your limit if needed."))
    conn.execute(
        "INSERT INTO expenses (title, amount, category, date) VALUES (?, ?, ?, ?)",
        (title, amount, category, date_value)
    )
    conn.commit()
    conn.close()
    return redirect(url_for("index", message="Expense added. Nice job keeping track!"))


@app.route("/edit/<int:expense_id>", methods=["POST"])
def edit_expense(expense_id):
    title = request.form.get("title", "").strip()
    category = request.form.get("category", "").strip()
    date_value = request.form.get("date", "").strip()
    try:
        amount = float(request.form.get("amount", "0"))
        parsed_date = date.fromisoformat(date_value)
    except (ValueError, TypeError):
        return redirect(url_for("index", error="Please enter a valid amount and date."))
    now = date.today()
    if not title or len(title) > 80 or amount <= 0 or category not in ALL_CATEGORIES:
        return redirect(url_for("index", error="Please check the expense details and try again."))
    if parsed_date.year != now.year or parsed_date.month != now.month:
        return redirect(url_for("index", error="Edited expenses must remain within the current month."))

    conn = get_db()
    existing = conn.execute("SELECT amount, date FROM expenses WHERE id = ?", (expense_id,)).fetchone()
    if existing is None:
        conn.close()
        return redirect(url_for("index", error="That expense could not be found."))
    month_key = now.strftime("%Y-%m")
    spent_without_this = conn.execute(
        "SELECT COALESCE(SUM(amount), 0) FROM expenses WHERE date LIKE ? AND id != ?",
        (month_key + "%", expense_id)
    ).fetchone()[0]
    budget = float(setting(conn, "monthly_budget", "25000"))
    if amount > max(0, budget - float(spent_without_this)):
        conn.close()
        return redirect(url_for("index", error="The edited amount would exceed your remaining budget."))
    conn.execute(
        "UPDATE expenses SET title = ?, amount = ?, category = ?, date = ? WHERE id = ?",
        (title, amount, category, date_value, expense_id)
    )
    conn.commit()
    conn.close()
    return redirect(url_for("index", message="Expense updated."))


@app.route("/delete/<int:expense_id>", methods=["POST"])
def delete_expense(expense_id):
    conn = get_db()
    conn.execute("DELETE FROM expenses WHERE id = ?", (expense_id,))
    conn.commit()
    conn.close()
    return redirect(url_for("index", message="Expense deleted."))


@app.route("/set-theme", methods=["POST"])
def set_theme():
    theme = request.form.get("theme", "light")
    if theme not in ("light", "dark"):
        theme = "light"
    conn = get_db()
    save_setting(conn, "theme", theme)
    conn.commit()
    conn.close()
    return redirect(url_for("index"))


@app.route("/set-mode", methods=["POST"])
def set_mode():
    mode = request.form.get("mode", "student")
    if mode not in ("student", "family"):
        mode = "student"
    conn = get_db()
    save_setting(conn, "mode", mode)
    conn.commit()
    conn.close()
    return redirect(url_for("index"))


@app.route("/set-budget", methods=["POST"])
def set_budget():
    try:
        budget = float(request.form.get("monthly_budget", "0"))
    except ValueError:
        return redirect(url_for("index", error="Enter a valid budget amount."))
    if budget <= 0 or budget > 100000000:
        return redirect(url_for("index", error="Budget must be greater than zero."))
    conn = get_db()
    save_setting(conn, "monthly_budget", budget)
    conn.commit()
    conn.close()
    return redirect(url_for("index", message="Your monthly limit has been updated."))


@app.route("/export")
def export_csv():
    conn = get_db()
    rows = conn.execute(
        "SELECT date, title, category, amount FROM expenses ORDER BY date DESC, id DESC"
    ).fetchall()
    conn.close()
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(["Date", "Description", "Category", "Amount (INR)"])
    for row in rows:
        writer.writerow([row["date"], row["title"], row["category"], row["amount"]])
    return Response(
        output.getvalue(),
        mimetype="text/csv",
        headers={"Content-Disposition": "attachment; filename=little-ledger-expenses.csv"}
    )


if __name__ == "__main__":
    init_db()
    app.run(debug=True)
